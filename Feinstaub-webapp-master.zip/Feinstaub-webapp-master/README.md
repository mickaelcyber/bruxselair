#LuftDatenWebApp

A webapp to visualize the data of the http://luftdaten.info project at the Open Knowledge Lab Stuttgart, Germany.

It uses angular.js, leaflet.js and D3.js.

https://github.com/opendata-stuttgart

http://stuttgart.maps.luftdaten.info/#11/48.8000/9.2000

One can build her/his own Particulate Matter sensor for around 30 €. The traduction of our Website in english will be published soon. You will find there the instructions to build the sensor.